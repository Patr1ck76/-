﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;

using System.Runtime.InteropServices;

using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace laba3kompzren
{
    public partial class Form1 : Form
    {
       
        Bitmap bit1;
        Bitmap bit2;
        

        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;


            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                if (bit1 != null) bit1.Dispose();
                if (bit2 != null) bit2.Dispose();
                bit1 = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = bit1;
            }

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                /*double Q;
                double.TryParse(textBox1.Text, out Q);*/
                double Q = Convert.ToDouble(textBox1.Text);

                bit1 = new Bitmap(pictureBox1.Image);
                bit2 = new Bitmap(bit1.Width, bit1.Height, PixelFormat.Format32bppRgb);

                

                Rectangle rect = new Rectangle(0, 0, bit1.Width, bit1.Height);

                
                BitmapData bitmapData1 = bit1.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppRgb);
                BitmapData bitmapData2 = bit2.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppRgb);
               
                
                int totalPixels = bit1.Width * bit1.Height;
                int bytesCount = totalPixels * 4; // 4 байта на пиксель (B, G, R, A)
                byte[] bytesInput = new byte[bytesCount];
                byte[] bytesOutput = new byte[bytesCount];

                Marshal.Copy(bitmapData1.Scan0, bytesInput, 0, bytesCount);

                // Первый проход: вычисляем среднюю яркость изображения
                double totalBrightness = 0;
                for (int i = 0; i < bytesCount; i += 4)
                {
                    byte b = bytesInput[i];
                    byte g = bytesInput[i + 1];
                    byte r = bytesInput[i + 2];
                    double brightness = 0.2126 * r + 0.7152 * g + 0.0722 * b; // яркость
                    totalBrightness += brightness;
                }


                double avgBrightness = totalBrightness / totalPixels;

                // Второй проход: обработка каждого пикселя
                for (int i = 0; i < bytesCount; i += 4)
                {
                    byte b = bytesInput[i];
                    byte g = bytesInput[i + 1];
                    byte r = bytesInput[i + 2];

                    double brightness = 0.2126 * r + 0.7152 * g + 0.0722 * b;

                    // Вычисляем новую яркость по формуле: z1 = z + Q * (z - avgBrightness)
                    double newBrightness = brightness + Q * (brightness - avgBrightness);
                    newBrightness = Math.Max(0, Math.Min(255, newBrightness)); // ограничение яркости в пределах [0, 255]

                    // Вычисляем коэффициент k
                    double k;
                    k = newBrightness / brightness;

                    
                    // Вычисляем новые компоненты цвета
                    
                    double newR = r * k;
                    double newG = g * k;
                    double newB = b * k;
                    // Корректируем если максимальный компонент превышает 255
                    double maxChannel = Math.Max(r, Math.Max(g, b));
                    if (maxChannel *k > 255)
                    {
                        double aK = 255 / maxChannel;
                        newR = r * aK;
                        newG = g * aK;
                        newB = b * aK;
                    }

                    // Записываем новые значения с обрезанием до диапазона 0-255
                    bytesOutput[i] = (byte)Math.Max(0, Math.Min(255, (int)newB));      // B
                    bytesOutput[i + 1] = (byte)Math.Max(0, Math.Min(255, (int)newG));  // G
                    bytesOutput[i + 2] = (byte)Math.Max(0, Math.Min(255, (int)newR));  // R
                }

                Marshal.Copy(bytesOutput, 0, bitmapData2.Scan0, bytesCount);
                bit1.UnlockBits(bitmapData1);
                bit2.UnlockBits(bitmapData2);

                pictureBox2.Image = bit2;
            }
    }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "JPEG Image|*.jpg|PNG Image|*.png";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ImageFormat format;
                if (saveFileDialog1.FilterIndex == 1)
                {
                    format = ImageFormat.Jpeg;
                }
                else
                {
                    format = ImageFormat.Png;
                }
                bit2.Save(saveFileDialog1.FileName, format);
            }
        }
    }
}
